// import React, { useEffect } from "react";
// import { connect } from "react-redux";
// import { useParams } from "react-router-dom";
// import CategoriesPage from "./CategoriesPage";

// export const CategoriesPageWrapper = (props) => {
//   let { handle } = useParams();
//   useEffect(() => {}, [handle]);
//   debugger;
//   console.log("Cat Params", handle);
//   return (
//     <>
//       <CategoriesPage catHandle={handle} />
//     </>
//   );
// };

// const mapStateToProps = (state) => ({});

// const mapDispatchToProps = {};

// export default connect(
//   mapStateToProps,
//   mapDispatchToProps
// )(CategoriesPageWrapper);
